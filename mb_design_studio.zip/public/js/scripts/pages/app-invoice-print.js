/*=========================================================================================
    File Name: app-invoice-print.js
    Description: app-invoice-print Javascript
    ----------------------------------------------------------------------------------------
    Item Name: Vuexy HTML Admin Template
   Version: 1.0
    Author: PIXINVENT
    Author URL: http://www.themeforest.net/user/pixinvent
==========================================================================================*/

$(function () {
  'use strict';

  window.print();
});
