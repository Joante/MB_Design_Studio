require('./bootstrap.min.js');

require('alpinejs');